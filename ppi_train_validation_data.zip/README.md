**EDIT:** I forgot to redundancy-reduce the test set against the validation set. BIG MISTAKE! I 
know -_- However, there is now a pair of new files: `huri_test_nrval.fasta` and 
`huri_test_nrval.tsv`. Accordingly, the number of pairs in each of the C123 classes has shrunk as 
shown in the table below:

| cclass | size | old size |
|--------|------|----------|
|      1 | 74   | 92       |
|      2 | 285  | 319      |
|      3 | 321  | 326      |


Each species forms its own, separate PPI network. Different per-species 
networks belong to different parts of the overall dataset: Four for training, 
four small ones for validation and hyperparameter tuning, one as test set.

There are 9967 + 894 + 492 = 11353 sequences and 152078 + 10343 + 8156 = 
170576 pairs (PPIs and negatives) in the dataset. 
**TODO:** Table with final n_ppis and n_seqs per species.

In general, each protein (or CRC sequence hash) has 10x as many negative 
interaction partners (which were sampled rather than observed) than true 
PPIs. However, there are some extra proteins that do not have positive 
interactions at all -- 2208, 349 and 25 for train, validate and test 
respectively. (They are not marked in the FASTA or the TSV, but there are 
separate FASTAs if you need them.) These were added so that the 10:1 ratio could 
be fulfilled for hub proteins that needed especially many negative partners. 
It will be interesting to know if or how easily a model learns to tell these 
proteins apart from the rest!?

**SOMEWHAT IMPORTANT** The TSV files are sorted! Positives come first. Then, both 
the first and the second column are sorted *downwards*, and the two hashes in 
each line are sorted lexicographically as well!

In addition to the protein hashes, the taxon id and the label (0 for no 
interaction, 1 for interaction), the TSV files for `validation` and `test` 
contain a `cclass` column that indicates whether both (1), one (2) or neither 
(3) of the sequences belonging to this pair are similar to a protein in the 
`train` set. Therefore, higher performance of a classifier on `C3` pairs 
means it will generalize better to new, unseen PPIs, which is a potentially 
more useful insight. There are 6725 `C3` pairs in the validation set for 
parameter optimization; 515 of which are actual positives = PPIs.

To reiterate: For a `C3` pair, both proteins are dissimilar to any protein in 
the training set; while both proteins in a `C1` pair `A-B` are similar to 
`A'` and `B'` in the training set, but this does *not* imply that a PPI 
`A'-B'` *must* appear in the training set! We use a HSSP-value >= 20 to 
define sequence similarity and the C1-3 classification is from Park,Y. and 
Marcotte,E.M. (2012) Flaws in evaluation schemes for pair-input computational 
predictions. Nature Methods, 9, 1134–1136. http://doi.org/10.1038/nmeth.2259

There are no pair interactions between two copies of the same protein in this 
dataset, and all sequences are between 50 and 1500aa.

The *Homo sapiens* interactome is a random 1/3 subset from Luck,K. et al. 
(2020) A reference map of the human binary protein interactome. Nature, 580, 
402–408. http://doi.org/10.1038/s41586-020-2188-x

and the other interactomes were extracted from Alonso-López,D. et al. (2019) 
APID database: redefining protein–protein interaction experimental evidences 
and binary interactomes. Database, 2019. 
http://doi.org/10.1093/database/baz005

`crc_hashes.tsv` contains the original UniProt / Ensembl sequence identifiers 
and the corresponding sequence hashes. Note that multiple IDs may point to 
the same sequence (hash); and that the original SwissProt headers for 
additional proteins without positive PPIs are not listed.


